package com.elite.improvedscanner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PointF;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.dlazaro66.qrcodereaderview.QRCodeReaderView;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;

public class QRActivity extends AppCompatActivity implements QRCodeReaderView.OnQRCodeReadListener {

    private QRCodeReaderView qrcodereaderview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        qrcodereaderview = findViewById(R.id.qrcodereaderview);

        qrcodereaderview.setOnQRCodeReadListener(this);
        qrcodereaderview.setQRDecodingEnabled(true);
        qrcodereaderview.setAutofocusInterval(2000L);
        qrcodereaderview.setTorchEnabled(true);
        qrcodereaderview.setFrontCamera();
        qrcodereaderview.setBackCamera();
    }

    @Override
    public void onQRCodeRead(String text, PointF[] points) {
        Intent TicketIntent = new Intent(this, MainActivity.class);
        TicketIntent.putExtra("code", text);

        XmlPullParserFactory xmlPullParserFactory;

        String uid = "", name = "", gender = "", yob = "", co = "", vtc = "", po = "", dist = "", state = "", pc = "", house = "",
                street = "", lm = "", subdist = "", dob = "";

        try {
            xmlPullParserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = xmlPullParserFactory.newPullParser();
            xmlPullParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            xmlPullParser.setInput(new StringReader(text));

            int eventType = xmlPullParser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_DOCUMENT) {

                } else if (eventType == XmlPullParser.START_TAG && DataAttributes.AADHAAR_DATA_TAG.equals(xmlPullParser.getName())) {
                    uid = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_UID_ATTR);
                    name = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_NAME_ATTR);
                    gender = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_GENDER_ATTR);
                    yob = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_YOB_ATTR);
                    co = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_CO_ATTR);

                    vtc = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_VTC_ATTR);
                    po = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_PO_ATTR);
                    dist = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_DIST_ATTR);
                    state = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_STATE_ATTR);
                    pc = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_PC_ATTR);

                    house = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_HOUSE_ATTR);
                    street = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_STREET_ATTR);
                    lm = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_LM_ATTR);
                    subdist = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_SUBDIST_ATTR);
                    dob = xmlPullParser.getAttributeValue(null, DataAttributes.AADHAAR_DOB_ATTR);

                } else if (eventType == XmlPullParser.END_TAG) {

                } else if (eventType == XmlPullParser.TEXT) {

                }

                eventType = xmlPullParser.next();
            }

        } catch (XmlPullParserException e) {
            Log.d(MainActivity.TAG, e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            Log.d(MainActivity.TAG, e.getMessage());
            e.printStackTrace();
        }

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("uid", uid);
        editor.commit();

        JSONObject jsonObject = null;

        try {
            jsonObject = XML.toJSONObject(text);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String filePath = "aadhaar";

        File file1 = new File(getExternalFilesDir(filePath), "aadhaar.xml");
        File file2 = new File(getExternalFilesDir(filePath), "aadhaar.json");

        try {
            FileOutputStream fileOutputStream1 = new FileOutputStream(file1);
            fileOutputStream1.write(text.getBytes());
            fileOutputStream1.close();

            String json = (new JSONObject(jsonObject.toString())).toString(4);

            FileOutputStream fileOutputStream2 = new FileOutputStream(file2);
            fileOutputStream2.write(json.getBytes());
            fileOutputStream2.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(QRActivity.this, MainActivity.class);
        intent.putExtra("status", "QR code scanned successfully.");
        startActivity(intent);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        qrcodereaderview.stopCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
        qrcodereaderview.startCamera();
    }
}
