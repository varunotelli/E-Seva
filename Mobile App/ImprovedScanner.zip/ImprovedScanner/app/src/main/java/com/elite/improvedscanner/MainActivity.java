package com.elite.improvedscanner;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView tv_docs;
    FloatingActionButton fab_plus, fab_fb, fab_twitter;
    Animation fab_open, fab_close, fab_rotate_clk, fab_rotate_anticlk, fab_open_2, fab_close_2;
    boolean isOpen = false;
    public static final String TAG = "check";
    public static final String AADHAAR_DIR = "aadhaar";
    public static final String CAMSCANNER_EXTERNAL_DIR = "/sdcard/CamScanner";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        Intent intent = getIntent();

        if (intent != null) {
            String s = intent.getStringExtra("status");

            if (s != null) {
                Log.i(TAG, "after scanning qr");
                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
            } else {
                String action = intent.getAction();
                String type = intent.getType();

                if ((Intent.ACTION_SEND_MULTIPLE.equals(action) || Intent.ACTION_SEND.equals(action)) && type.endsWith("pdf")) {

                    if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {

                        Log.i(TAG, "multiple files from camscanner");

                        ArrayList<Uri> arrayList = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);

                        FileInputStream fileInputStream;
                        FileOutputStream fileOutputStream;

                        for (int i = 0; i < arrayList.size(); i++) {

                            File file1 = new File(CAMSCANNER_EXTERNAL_DIR, arrayList.get(i).getLastPathSegment());
                            File file2 = new File(getExternalFilesDir(AADHAAR_DIR), arrayList.get(i).getLastPathSegment());

                            try {
                                fileInputStream =
                                        new FileInputStream(file1);
                                fileOutputStream =
                                        new FileOutputStream(file2);

                                byte[] buffer = new byte[1024];
                                int read;

                                while ((read = fileInputStream.read(buffer)) != -1) {
                                    fileOutputStream.write(buffer, 0, read);
                                }

                                fileInputStream.close();
                                // write the output file (You have now copied the file)
                                fileOutputStream.flush();
                                fileOutputStream.close();

                            } catch (FileNotFoundException e) {
                                Log.e(TAG, e.getMessage());
                            } catch (Exception e) {
                                Log.e(TAG, e.getMessage());
                            }
                        }
                    } else {

                        Log.i(TAG, "single file from camscanner");

                        Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);

                        FileInputStream fileInputStream;
                        FileOutputStream fileOutputStream;

                        File file1 = new File(CAMSCANNER_EXTERNAL_DIR, uri.getLastPathSegment());
                        File file2 = new File(getExternalFilesDir(AADHAAR_DIR), uri.getLastPathSegment());

                        try {
                            fileInputStream =
                                    new FileInputStream(file1);
                            fileOutputStream =
                                    new FileOutputStream(file2);

                            byte[] buffer = new byte[1024];
                            int read;

                            while ((read = fileInputStream.read(buffer)) != -1) {
                                fileOutputStream.write(buffer, 0, read);
                            }

                            fileInputStream.close();
                            // write the output file (You have now copied the file)
                            fileOutputStream.flush();
                            fileOutputStream.close();

                        } catch (FileNotFoundException e) {
                            Log.e(TAG, e.getMessage());
                            e.printStackTrace();
                        } catch (Exception e) {
                            Log.e(TAG, e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        Log.i(TAG, "Displaying current docs");

        tv_docs = findViewById(R.id.tv_docs);

        File directory = new File(getExternalFilesDir(AADHAAR_DIR).getPath());
        File[] files = directory.listFiles();

        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                tv_docs.append(files[i].getName() + "\n");
            }
        }

        //app logic ends here

        fab_plus = findViewById(R.id.fab_plus);
        fab_fb = findViewById(R.id.fab_share);
        fab_twitter = findViewById(R.id.fab_delete);

        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);

        fab_open_2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open_2);
        fab_close_2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close_2);

        fab_rotate_clk = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_rotate_clk);
        fab_rotate_anticlk = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_rotate_anticlk);

        fab_plus.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (isOpen) {
                            fab_plus.startAnimation(fab_rotate_anticlk);
                            fab_fb.startAnimation(fab_close);
                            fab_twitter.startAnimation(fab_close_2);
                            fab_fb.setClickable(false);
                            fab_twitter.setClickable(false);
                            isOpen = false;
                        } else {
                            fab_plus.startAnimation(fab_rotate_clk);
                            fab_fb.startAnimation(fab_open);
                            fab_twitter.startAnimation(fab_open_2);
                            fab_fb.setClickable(true);
                            fab_twitter.setClickable(true);
                            isOpen = true;
                        }
                    }
                }
        );

    }

    public void scanQR(View view) {
        Intent intent = new Intent(this, QRActivity.class);
        startActivity(intent);
        finish();
    }

    public void launchCamScan(View view) {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.intsig.camscanner");
        if (intent != null) {
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Please install CamScanner app.", Toast.LENGTH_SHORT).show();
        }
    }

    public void shareBT(View view) {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Oops! Bluetooth not supported.", Toast.LENGTH_SHORT).show();
        } else {
            ArrayList<Uri> arrayList = new ArrayList<>();
            String path = getString(R.string.sd_aadhaar);
            Log.d(TAG, path);
            File directory = new File(path);
            File[] files = directory.listFiles();

            for (int i = 0; i < files.length; i++) {
                Log.d(TAG, files[i].getName());
                arrayList.add(i, Uri.fromFile(files[i]));
            }

            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_SEND_MULTIPLE);
            intent.setType("*/*");
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, arrayList);
            startActivity(intent);
        }
    }

    public void delete(View view) {
        String path = getString(R.string.sd_aadhaar);
        File directory = new File(path);
        File[] files = directory.listFiles();

        String path_cam_scan = "/sdcard/CamScanner/";

        for (int i = 0; i < files.length; i++) {

            File file = new File(path_cam_scan + files[i].getName());

            if (file.exists()) {
                file.delete();
            }

            files[i].delete();
        }

        tv_docs.setText("");
        Toast.makeText(this, "All docs are erased successfully", Toast.LENGTH_SHORT).show();
    }
}
