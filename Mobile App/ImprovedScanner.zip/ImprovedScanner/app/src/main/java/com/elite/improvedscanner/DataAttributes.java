package com.elite.improvedscanner;

/**
 * Created by evk29 on 13-03-2018.
 */

public class DataAttributes {

        public static final String AADHAAR_DATA_TAG = "PrintLetterBarcodeData",
                AADHAAR_UID_ATTR = "uid",
                AADHAAR_NAME_ATTR = "name",
                AADHAAR_GENDER_ATTR = "gender",
                AADHAAR_YOB_ATTR = "yob",
                AADHAAR_CO_ATTR = "co",
                AADHAAR_HOUSE_ATTR = "house",
                AADHAAR_STREET_ATTR = "street",
                AADHAAR_LM_ATTR = "lm",
                AADHAAR_VTC_ATTR = "vtc",
                AADHAAR_PO_ATTR = "po",
                AADHAAR_DIST_ATTR = "dist",
                AADHAAR_SUBDIST_ATTR = "subdist",
                AADHAAR_STATE_ATTR = "state",
                AADHAAR_PC_ATTR = "pc",
                AADHAAR_DOB_ATTR = "dob";
}
